//
//  MapKitViewController.swift
//  Reminder
//
//  Created by Raghad Ali on 12/21/17.
//  Copyright © 2017 Raghad Ali. All rights reserved.
//

import UIKit
import CoreLocation
import MapKit
import SharkORM 
class MapKitViewController: UIViewController, CLLocationManagerDelegate, MKMapViewDelegate, UISearchBarDelegate {
    
    
    var locationManger: CLLocationManager!
    @IBOutlet weak var mapView: MKMapView!
    var currentLocation : CLLocation?
    var Annotation = MKPointAnnotation()
    var next_lat :Double! = 0.0
    var next_lon:Double! = 0.0
    var fetchData: [ReminderDataBase]! = []
    var latlong : [String:Double]! = [:]
    
    
    
    override func viewDidLoad() {
        
        locationManger = CLLocationManager()
        locationManger.delegate = self
        locationManger.desiredAccuracy = kCLLocationAccuracyBest
        locationManger.requestWhenInUseAuthorization()
        //  locationManger.stopUpdatingLocation()
        locationManger.startUpdatingLocation()
        super.viewDidLoad()
        
    }
    @IBAction func AddButtonTapped(_ sender: Any) {
        
        if next_lat > 0 && next_lon > 0 {
            // store in sharkORM & redirect to add reminder page
            let location: Data = NSKeyedArchiver.archivedData(withRootObject: latlong)
            let locatioId:ReminderDataBase =  ReminderDataBase.query().where(withFormat: "id=%i", withParameters: [self] ).fetch().firstObject as!ReminderDataBase
            let addReminderVC : AddReminderViewController = self.storyboard?.instantiateViewController(withIdentifier: "AddReminderViewController") as! AddReminderViewController
            addReminderVC.locationTOStore = location
            self.navigationController?.pushViewController(addReminderVC, animated: true)
        }
        else {
            AlertController.showAlert(self, titlee: "warnning", messagee: "add your next location")
        }
    }
  
   
  
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        
        let location = locations[0]
        let locationString =  ["31.037069","31.357028"]
        var locations : [CLLocation] = []
        currentLocation = location
        let center = CLLocationCoordinate2D(latitude: (location.coordinate.latitude), longitude: (location.coordinate.longitude))
        var region = MKCoordinateRegion(center: center, span: MKCoordinateSpan(latitudeDelta: 0.01, longitudeDelta: 0.01))
        region.center = mapView.userLocation.coordinate
        
        //TO Set Annotation
        Annotation.coordinate = location.coordinate
        mapView.addAnnotation(Annotation)

        // pass lat and long
        self.mapView.showsUserLocation  = true
        latlong = ["current_lat":location.coordinate.latitude ,"current_long":location.coordinate.longitude, "next_lat": next_lat , "next_long":next_lon]
       
        
        
        // TO CONVERT locatioString to CLLocation
        for locationString in locationString {
            let location = CLLocation(latitude: 31.037069, longitude: 31.357028)
            locations.append(location)
        }
        
        // to calculate distance b/w my location and pin location
        for location in locations {
            let distanceMeters = currentLocation?.distance(from: location)
            if distanceMeters == 1000 {
                AlertController.showAlert(self, titlee: "Attention", messagee: "Reminder said you have something to do here")
            }
        }
        func tofetch() {
            fetchData = ReminderDataBase.query().fetch() as![ReminderDataBase]
            print(fetchData)
        }
        
        
            
        
        
        
       
       
//        func toStoreLocation() {
//            let locationDictionary:[String: Double] = ["lat": center.latitude , "long": center.longitude]
//            var locationArray = [[String :Double]]()
//        }
       
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        //

//        for pin in pins {
//
//            pin.location
//            currentLocation
//
//            calculate the distance between my location and pin location
//
//            if distance < 1000 m : present O_ALERT
//            else : nothing
//
//        }
        
        
    }

}
