//
//  TestMapkitViewController.swift
//  ToDoList
//
//  Created by Raghad Ali on 12/26/17.
//  Copyright © 2017 Raghad Ali. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation

class TestMapkitViewController: UIViewController {
    
    
    @IBOutlet weak var directionslabel: UILabel!
    @IBOutlet weak var searchBar : UISearchBar!
    @IBOutlet weak var mapView : MKMapView!
    
    let locationManager = CLLocationManager()
    var currentCoordinate: CLLocationCoordinate2D!
    
    override func viewDidLoad() {
        super.viewDidLoad()
   locationManager.requestAlwaysAuthorization()
   locationManager.delegate = self
   locationManager.desiredAccuracy = kCLLocationAccuracyBestForNavigation
   locationManager.stopUpdatingLocation()
    mapView.showsUserLocation  = true
       
    }
    
    func getDirections(to destination: MKPlacemark) {
        
    }
}

extension TestMapkitViewController: CLLocationManagerDelegate {
    
    public func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
       manager.stopUpdatingLocation()
        guard let currentLocation = locations.first else {return}
        currentCoordinate = currentLocation.coordinate
        mapView.userTrackingMode = .followWithHeading
        print(currentLocation.coordinate.latitude)
        print(currentLocation.coordinate.longitude)
       
       
        
    }
    
}
extension TestMapkitViewController: UISearchBarDelegate {
    public func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
        searchBar.endEditing(true)
    let localSearchRequest = MKLocalSearchRequest()
        localSearchRequest.naturalLanguageQuery = searchBar.text
        let region = MKCoordinateRegion(center: currentCoordinate, span: MKCoordinateSpan(latitudeDelta: 0.1, longitudeDelta: 0.1))
        localSearchRequest.region = region
        let localSearch = MKLocalSearch(request: localSearchRequest)
        localSearch.start { (response, _) in
            guard let response  = response else { return }
            print(response.mapItems)
            guard let firstMapItem  = response.mapItems.first else {return}
            self.getDirections(to: firstMapItem.placemark)
        }
    }
}
extension TestMapkitViewController: MKMapViewDelegate{
    // to show bluepath directions
    public func mapView(_ mapView: MKMapView, rendererFor overlay: MKOverlay) -> MKOverlayRenderer {
        return MKOverlayRenderer()
    }
}
