//
//  ReminderDataBase.swift
//  ToDoList
//
//  Created by Raghad Ali on 12/24/17.
//  Copyright © 2017 Raghad Ali. All rights reserved.
//


import SharkORM

class ReminderDataBase: SRKObject {
    
    @objc  dynamic var keyinTable: String?
    @objc  dynamic var title:String?
    @objc  dynamic var information:String?
    @objc dynamic var time: Date?
    @objc dynamic var location: Data?
   
    
    

   
    
}
