//
//  AlertController.swift
//  Firebase-Login
//
//  Created by Raghad Ali on 12/5/17.
//  Copyright © 2017 Raghad Ali. All rights reserved.
//

import UIKit

class AlertController: UIAlertController {
    static func showAlert(_ inviewcontroller: UIViewController, titlee: String, messagee: String) {
        let alert = UIAlertController(title: titlee, message: messagee, preferredStyle: .alert)
        let action = UIAlertAction(title: "OK", style: .default, handler: nil)
        alert.addAction(action)
        inviewcontroller.present(alert, animated: true, completion: nil)
    }
    
}
