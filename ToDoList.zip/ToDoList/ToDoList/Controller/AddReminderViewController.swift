//
//  AddReminderViewController.swift
//  Reminder
//
//  Created by Raghad Ali on 12/18/17.
//  Copyright © 2017 Raghad Ali. All rights reserved.
//

import UIKit
import SharkORM

class AddReminderViewController: UIViewController, UITextFieldDelegate{
    
    var reminder: Reminder!
    @IBOutlet weak var InfoTF: UITextField!
    @IBOutlet weak var saveButtonTapped: UIBarButtonItem!
    @IBOutlet weak var reminderTF: UITextField!
    @IBOutlet weak var timePicker: UIDatePicker!
    var key : String!
    var locationTOStore:Data!
    var output:ReminderDataBase!
    
    @IBAction func userLocationButton(_ sender: Any) {
        
        let mapShow : MapKittttViewController = self.storyboard?.instantiateViewController(withIdentifier: "MapKittttViewController") as! MapKittttViewController
        self.navigationController?.pushViewController(mapShow, animated: true)
        
    }
  
   
    @IBOutlet weak var location: UIButton!
   
//    @IBOutlet weak var lblToshowInfo: UILabel!
    @IBAction func saveButton(_ sender: Any) {
        tostore()
        let title = reminderTF.text
        let information = InfoTF.text
        let time = timePicker.date
       // let location = self.location
        

        let notification = UILocalNotification()
        notification.alertTitle = "\(String(describing: title))"
        notification.alertAction = ""
        notification.alertBody = "\(information!) "
        notification.fireDate = time
        notification.soundName = UILocalNotificationDefaultSoundName;
        UIApplication.shared.scheduleLocalNotification(notification)

        reminder =  Reminder(title:title!, information: information!,time: time, notification: notification)
        
        let saveButton : ReminderTVViewController = self.storyboard?.instantiateViewController(withIdentifier: "ReminderTVViewController") as! ReminderTVViewController;
        saveButton.reminder = [reminder!]
        self.navigationController?.pushViewController(saveButton, animated: true)
    }
    
    
    @IBAction func listAllButtonTapped(_ sender: Any) {
        let destination = self.storyboard?.instantiateViewController(withIdentifier: "ReminderTVViewController") as! ReminderTVViewController
        navigationController?.pushViewController(destination, animated: true)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.reminderTF.delegate = self
        self.InfoTF.delegate = self
        //set date/time as PICKER
        timePicker.minimumDate = NSDate() as Date
        timePicker.locale  = NSLocale.current
       // location.isHidden = true
        //selfsaveButtonTapped.isEnabled = false
        //checkLocationAtStart()
       
    // ReminderDataBase.query().fetch().removeAll()
        print(locationTOStore)
       //viewWillAppear(true)
        
        if output != nil{
            reminderTF.text? = output.title!
            InfoTF.text? = output.information!
            timePicker.date = output.time!
            
        }
        
        
           }
    
    // when pressed back button all fields are empty
//    override func viewWillAppear(_ animated: Bool) {
//        reminderTF.text? = ""
//        InfoTF.text? = ""
//    }
//
    func checkLocationAtStart(){
        if locationTOStore == nil {
            saveButtonTapped.isEnabled = false
            AlertController.showAlert(self, titlee: "Message", messagee: "Welcome here, at first Insert your next location")
        }
        else {
            saveButtonTapped.isEnabled = true
        }
    }
    

       // func to check if the TF empty or not ??
        func checkNameandtitle() {
          
            
//            if reminderTF.text! == "" || InfoTF.text! == "" {
//                saveButtonTapped.isEnabled = !(text?.isEmpty)!
//                //AlertController.showAlert(self, titlee: "Warning", messagee: "Fill your Reminder!")
//            }
//            else {
//                AlertController.showAlert(self, titlee: "Warning", messagee: "Fill All Data")
//            }
//
       // Disabled saveButton when TF Empty
        let text = reminderTF.text;
        let text2 = InfoTF.text
        saveButtonTapped.isEnabled = !(text?.isEmpty)!
        saveButtonTapped.isEnabled = !(text2?.isEmpty)!
        
        }
        // TO Disply KB
        override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
            reminderTF.endEditing(true)
        }
    
        // func to check Date
        func checkDate() {
            //Disabled saveBUtton when picker is not passed
            if NSDate().earlierDate(timePicker.date) == timePicker.date
            {
                saveButtonTapped.isEnabled = false
            }
        }
        func textFieldShouldReturn(_ textField: UITextField) -> Bool {
            textField.resignFirstResponder()
            textField.resignFirstResponder()
         
            return true
        }
    
        func textFieldDidEndEditing(_ textField: UITextField) {
            checkNameandtitle()
            
        }
        func textFieldDidBeginEditing(_ textField: UITextField) {
            saveButtonTapped.isEnabled = false
            
               }
    
        @IBAction func dateChange(_ sender: UIDatePicker) {
            checkDate()
        }
    
        // In a storyboard-based application, you will often want to do a little preparation before navigation
        override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
            // Get the new view controller using segue.destinationViewController.
            // Pass the selected object to the new view controller.
            if saveButtonTapped == (sender as? UIBarButtonItem) {
                let title = reminderTF.text
                let information = InfoTF.text
                let time = timePicker.date
                
                
                // TO SEND NOTIFICATION
                
                let notification = UILocalNotification()
                notification.alertTitle = "To-Do-list"
                notification.alertBody = "Don't Forget to \(title!)  \(information!) + \(location)"
                notification.fireDate = time
                notification.soundName = UILocalNotificationDefaultSoundName;
                UIApplication.shared.scheduleLocalNotification(notification)
                reminder =  Reminder(title:title!, information: information!,time: time, notification: notification)
                
            }
     

        }
        func tostore() {
            let storeReminderObject = ReminderDataBase()
            storeReminderObject.title = reminderTF.text
            storeReminderObject.information = InfoTF.text
            storeReminderObject.time = timePicker.date
            storeReminderObject.id =  (returnCountOfObjectsFromSRK() + 1 ) as NSNumber
            storeReminderObject.location = locationTOStore
            storeReminderObject.commit()
            
        }

    func returnCountOfObjectsFromSRK () -> Int{
        
        let remind:[ReminderDataBase] =  ReminderDataBase.query().fetch() as! [ReminderDataBase]
        
        return remind.count
        
    }
    
}
