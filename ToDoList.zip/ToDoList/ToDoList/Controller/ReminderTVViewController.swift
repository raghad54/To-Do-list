//
//  ReminderTVViewController.swift
//  Reminder
//
//  Created by Raghad Ali on 12/23/17.
//  Copyright © 2017 Raghad Ali. All rights reserved.


import UIKit
import SharkORM

class ReminderTVViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    
    @IBOutlet var tableView: UITableView!
   
    var reminder = [Reminder]()
    let dataFormatter = DateFormatter()
    let locale = Locale.current // to get time of user's location
    var infoPassingData:String!
    var fetchData :[ReminderDataBase]! = []
    

    override func viewDidLoad() {
        super.viewDidLoad()
        
        //DateFormatting Settings
        dataFormatter.locale = locale
        dataFormatter.dateStyle = .medium
        dataFormatter.timeStyle = .short
        reloadData()
        if navigationItem.backBarButtonItem?.isEnabled == true {
            
        }
    }
    
    
    
    func reloadData(){
        tofetch()
        
        
    }
    
    
   @IBAction func pushAddNewToDo (_ sender:NSObject) {
        
        let addReminderVC : AddReminderViewController = self.storyboard?.instantiateViewController(withIdentifier: "AddReminderViewController") as! AddReminderViewController
        self.navigationController?.pushViewController(addReminderVC, animated: true)
        
        
    }


     func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return fetchData.count
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat
    {
        return UITableViewAutomaticDimension
        
    }
    
     func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "reminderCell", for: indexPath)
        // info in table
       let reminderObject = self.fetchData[indexPath.row]
        cell.tag =  (reminderObject.id ).intValue
        cell.textLabel?.numberOfLines = 0
        //cell.textLabel?.text = reminder.name
        cell.textLabel?.text = "\(String(describing: reminderObject.title!))" +  "\n \(String(describing: reminderObject.information! ))"
        cell.detailTextLabel?.text =  dataFormatter.string(from: (reminderObject.time as? Date)!)
        //cell.textLabel?.text = reminder.title
        
        return cell
    }
    
    
    
    //  to support conditional editing of the table view.
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }

    
     func tableView(_ tableView: UITableView, editActionsForRowAt indexPath: IndexPath) -> [UITableViewRowAction]? {
        let cell1 = tableView.cellForRow(at: indexPath)
        let moreRowAction  = UITableViewRowAction(style: UITableViewRowActionStyle.default, title: "More", handler:{  ACTION , indexPath in print("MORE.ACTION")
            
            let reminderObject = self.fetchData[indexPath.row]
            let outPutRem:ReminderDataBase =  ReminderDataBase.query().where(withFormat: "id=%i", withParameters: [cell1?.tag as Any] ).fetch().firstObject as!ReminderDataBase
            
           let distination = self.storyboard?.instantiateViewController(withIdentifier: "PopUpViewController") as! popUpViewController
            distination.displayOutput = outPutRem
            self.navigationController?.pushViewController(distination, animated: true)
        
        })
        moreRowAction.backgroundColor = UIColor.lightGray
        
        let DeleteRowAction = UITableViewRowAction(style: UITableViewRowActionStyle.default, title: "Delete", handler: {
            ACTION , indexPath in print("DELETE.ACTION")
          
            let showMessage = UIAlertController(title: "Delete Message", message: "Are you sure you want to delete this", preferredStyle: UIAlertControllerStyle.alert)
            self.present(showMessage, animated: true, completion: nil)
            showMessage.addAction(UIAlertAction(title: "Yes", style: .default, handler: { Action in
            ReminderDataBase.query().where(withFormat: "id=%i", withParameters: [cell1?.tag as Any]).fetch().removeAll()
            self.reloadData()
            }))
           
        })
        let EditRowAction = UITableViewRowAction(style: UITableViewRowActionStyle.default, title: "edit" , handler: { ACTION,  indexPath in print("edit.Action")
            
            let reminderObject = self.fetchData[indexPath.row]
            let outPutRem:ReminderDataBase =  ReminderDataBase.query().where(withFormat: "id=%i", withParameters: [cell1?.tag as Any] ).fetch().firstObject as!ReminderDataBase
            let distination = self.storyboard?.instantiateViewController(withIdentifier: "AddReminderViewController")  as! AddReminderViewController
            distination.output = outPutRem
           self.navigationController?.pushViewController(distination, animated: true)
            self.reloadData()


        })
        EditRowAction.backgroundColor = .gray
        tableView.setEditing(true, animated: true)
        return [moreRowAction , DeleteRowAction , EditRowAction]
    }
    
    
    
    

    //NSCoding
    func saveReminders() {
        let isSuccessfulSave =  NSKeyedArchiver.archiveRootObject(reminder, toFile: Reminder.ArchiveuRL.path)
        if (isSuccessfulSave) {
            print("Reminders save successfully!")
        }
        else {
            print("Faild to save ur Reminders :(")
        }
    }
    
//    func LoadReminders() -> [Reminder]? {
//        var returnm:[Reminder]! = []
//        if  reminder.count > 0 {
//            for reminderObject in reminder  {
//                returnm .append(reminderObject)
//
//            }
//        }
//        return returnm
//
//    }
    
    func tofetch() {
       fetchData = ReminderDataBase.query().fetch() as![ReminderDataBase]
        print(ReminderDataBase.query().fetch())
        tableView.reloadData()
    }

}
