
//
//  Reminder.swift
//  Reminder
//
//  Created by Raghad Ali on 12/18/17.
//  Copyright © 2017 Raghad Ali. All rights reserved.
//

import Foundation
import UIKit
import UserNotifications
class Reminder: NSObject, NSCoding {
  
    //Properties
    var title: String!
    var information: String!
    var time =  Date()
    var notification: UILocalNotification
    
    // Archive path for persistent Date
    static let DecumnetDirectory =  try! FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: false)
    static let ArchiveuRL = DecumnetDirectory.appendingPathComponent("Reminders")
    
    //enum for propertykey
    struct propertykey {
        static let informationKey = "information"
        static let titleKey = "title"
        static let timeKey = "time"
        static let notificationKey = "notification" }
    
     // Initilizer
    init(title: String , information: String, time: Date , notification: UILocalNotification) {
        self.title = title
        self.information = information
        self.time = time
        self.notification = notification
        super.init()
        }
        //Destructor that's delete notification of reminder befor in fireup
        deinit {
            //cancel notification
            UIApplication.shared.cancelLocalNotification(self.notification)
        }
    //coding
    func encode(with aCoder: NSCoder) {
        aCoder.encode(information, forKey: propertykey.informationKey)
        aCoder.encode(title, forKey: propertykey.titleKey)
        aCoder.encode(time, forKey: propertykey.timeKey)
        aCoder.encode(notification, forKey: propertykey.notificationKey)
    }
    //Encoding
    required convenience init?(coder aDecoder: NSCoder) {
        let name = aDecoder.decodeObject(forKey:propertykey.informationKey)
        let title = aDecoder.decodeObject(forKey:propertykey.titleKey)
        let time = aDecoder.decodeObject(forKey:propertykey.timeKey)
        let notification = aDecoder.decodeObject(forKey:propertykey.notificationKey)
        self.init( title: title as! String, information: name as! String, time: time as! Date, notification: notification as! UILocalNotification)

    }
}
