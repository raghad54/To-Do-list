//
//  MapKittttViewController.swift
//  ToDoList
//
//  Created by Raghad Ali on 12/26/17.
//  Copyright © 2017 Raghad Ali. All rights reserved.
//
import UIKit
import CoreLocation
import MapKit
import SharkORM


class MapKittttViewController: UIViewController, CLLocationManagerDelegate, UIGestureRecognizerDelegate, MKMapViewDelegate, UISearchBarDelegate{
    
    
    var locationManger: CLLocationManager!
    var currentLocation : CLLocation?
    var currentCoordinate: CLLocationCoordinate2D!
    var next_lat :Double!
    var next_lon:Double!
    var current_lat : Double!
    var current_lon : Double!
    var fetchData: [ReminderDataBase]! = []            //Reminders
    var latlong : [String:Double]! = [:]
    private var searchController: UISearchController!
    private var localSearchRequest: MKLocalSearchRequest!
    private var localSearch: MKLocalSearch!
    private var localSearchResponse: MKLocalSearchResponse!
    @IBOutlet weak var _mapView: MKMapView!
    
    override func viewDidLoad() {
        
        
        locationManger = CLLocationManager()
        locationManger.delegate = self
        locationManger.desiredAccuracy = kCLLocationAccuracyBest
        locationManger.requestWhenInUseAuthorization()
        locationManger.startUpdatingLocation()
        super.viewDidLoad()
        
        
    }
    
   
    @IBAction func listAllButtonTapped(_ sender: Any) {
        let destination = self.storyboard?.instantiateViewController(withIdentifier: "ReminderTVViewController") as! ReminderTVViewController
        navigationController?.pushViewController(destination, animated: true)
    }
    


    @IBAction func action(gestureRecognizer:UIGestureRecognizer){

        _mapView.removeAnnotations(_mapView.annotations)
        let touchPoint = gestureRecognizer.location(in: _mapView)
        let newCoordinates = _mapView.convert(touchPoint, toCoordinateFrom: _mapView)
        print("lat: \(newCoordinates.latitude) and long: \(newCoordinates.longitude)")
       //add Annotation
        let annotation = MKPointAnnotation()
        annotation.coordinate = newCoordinates
        next_lat = newCoordinates.latitude
        next_lon = newCoordinates.longitude
        _mapView.addAnnotation(annotation)
    }
    @IBAction func addButtonTapped(_ sender: Any) {
        
         setLocationPoints ()
        if next_lat != nil  && next_lon != nil{
            self.perform(#selector(setlocation), with: nil, afterDelay: 1)
      }
         
    }
    

    
    func setLocationPoints (){
        if (next_lat == nil) && (next_lat == nil){
            AlertController.showAlert(self, titlee: "Warning", messagee: "Select the location of your next Reminder !")
        }
        else {
        latlong = ["current_lat":current_lat ,"current_long":current_lon, "next_lat": next_lat , "next_long":  next_lon]
        }
    }
    
    @objc func setlocation(){
        let location: Data = NSKeyedArchiver.archivedData(withRootObject: latlong)
        let addReminderVC : AddReminderViewController = self.storyboard?.instantiateViewController(withIdentifier: "AddReminderViewController") as! AddReminderViewController
        addReminderVC.locationTOStore = location
       self.navigationController?.pushViewController(addReminderVC, animated: true)
        
    }
  
    
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        
        let location = locations[0]
        let locationString =  [next_lon,next_lat]
        var locations : [CLLocation] = []
        currentLocation = location
        let center = CLLocationCoordinate2D(latitude: (location.coordinate.latitude), longitude: (location.coordinate.longitude))
        var region = MKCoordinateRegion(center: center, span: MKCoordinateSpan(latitudeDelta: 0.01, longitudeDelta: 0.01))
        region.center = _mapView.userLocation.coordinate
        _mapView.setRegion(region, animated: true)
        current_lat = location.coordinate.latitude
        current_lon = location.coordinate.longitude
        self._mapView.showsUserLocation = true
        let initialLocation = CLLocation(latitude: current_lat, longitude: current_lon)
        // when user getout from App isn't important to update the location
        //locationManger.stopUpdatingLocation()
        
        // TO CONVERT locatioString to CLLocation
        for locationString in locationString {
            let location = CLLocation(latitude: current_lat, longitude: current_lon)
            locations.append(location)
        }
        
        // to calculate distance b/w my location and pin location
        for location in locations {
            let distanceMeters = currentLocation?.distance(from: location)
            if distanceMeters == 1000 {
                AlertController.showAlert(self, titlee: "Attention", messagee: "Reminder said you have something to do here")
            }
             }
        
    }



    
//        @IBAction func searchButton(_ sender: Any) {
//            let searchController = UISearchController(searchResultsController: nil)
//            searchController.searchBar.delegate = self as UISearchBarDelegate
//            present(searchController, animated: true, completion: nil)
//        }
//
//        func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
//            //Ignoring user
//            UIApplication.shared.beginIgnoringInteractionEvents()
//             //Activity indictor
//            let activityIndicator = UIActivityIndicatorView()
//            activityIndicator.activityIndicatorViewStyle = UIActivityIndicatorViewStyle.gray
//            activityIndicator.center = self.view.center
//            activityIndicator.hidesWhenStopped = true
//            activityIndicator.stopAnimating()
//            self.view.addSubview(activityIndicator)
//            //Hide search bar
//            searchBar.resignFirstResponder()
//            dismiss(animated: true, completion: nil)
//
//            //Create the search request
//            let  searchRequest = MKLocalSearchRequest()
//            searchRequest.naturalLanguageQuery = searchBar.text
//            let activeSearch = MKLocalSearch(request: searchRequest)
//            activeSearch.start { (response, error) in
//                if response == nil {
//                    print("Error")
//                }
//                else {
//                    //Remove annotation
//                    let annotations = self._mapView.annotations
//                    //self._mapView.removeAnnotation(annotations as! MKAnnotation)
//                    //Getting data
//                    self.next_lat = response?.boundingRegion.center.latitude
//                    self.next_lon = response?.boundingRegion.center.longitude
//                    //create annotation
//                    let annoation = MKPointAnnotation()
//                    annoation.title = searchBar.text
//                    annoation.coordinate = CLLocationCoordinate2DMake(self.next_lat!,self.next_lon!)
//                    self._mapView.addAnnotation(annoation)
//                    //Zooming in on annotation
//                    let coordinate:CLLocationCoordinate2D = CLLocationCoordinate2DMake(self.next_lat! , self.next_lon!)
//                    let span = MKCoordinateSpanMake(0.1, 0.1)
//                    let region = MKCoordinateRegionMake(coordinate, span)
//                    self._mapView.setRegion(region, animated: true)
//
//
//                }
//            }
//
        }



