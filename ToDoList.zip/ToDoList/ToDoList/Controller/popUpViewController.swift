//
//  popUpViewController.swift
//  ToDoList
//
//  Created by Raghad Ali on 12/31/17.
//  Copyright © 2017 Raghad Ali. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation
import SharkORM

class popUpViewController: UIViewController , MKMapViewDelegate, CLLocationManagerDelegate {

    @IBOutlet weak var titlelbl: UILabel!
    @IBOutlet weak var informationlbl: UILabel!
    @IBOutlet weak var timelbl: UILabel!
    @IBOutlet weak var mapView: MKMapView!
    var currentLatitude:Double!
    var currentLongitude:Double!
    var nextLatitude:Double!
    var nextLongitude:Double!
    var displayOutput : ReminderDataBase!
    var mapShow: MapKittttViewController!
    var locationManger: CLLocationManager!
    var currentLocation : CLLocation?
    var currentCoordinate: CLLocationCoordinate2D!
    var newPin: MKPointAnnotation!

    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        locationManger = CLLocationManager()
        locationManger.delegate = self
        locationManger.desiredAccuracy = kCLLocationAccuracyBest
        locationManger.requestWhenInUseAuthorization()
        fetchLocation(passedLocation: displayOutput.location)
        ToDisplayReminderData()
        let customLocation = CLLocationCoordinate2DMake(nextLatitude, nextLongitude)
        let customLocationDrop = MKPointAnnotation()
        customLocationDrop.coordinate = customLocation
        customLocationDrop.title = "your next Reminder here"
        mapView.addAnnotation(customLocationDrop)
    }
    
    func ToDisplayReminderData(){
        if displayOutput != nil{
            
        titlelbl.text! = displayOutput.title!
        titlelbl.font = UIFont(name: "Apple SD Gothic Neo", size: 24)
        informationlbl.text! = displayOutput.information!
        informationlbl.font = UIFont(name: "Apple SD Gothic Neo", size: 24)
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "dd-MM-yyyy HH:mm"
        timelbl.text = dateFormatter.string(from: displayOutput.time!)
        timelbl.font = UIFont(name: "Apple SD Gothic Neo " , size: 24)
          }
    }
   
    func fetchLocation(passedLocation:Data!) {
       let unarchiveLocation =  (NSKeyedUnarchiver.unarchiveObject(with: passedLocation)  as? NSDictionary)!
       nextLatitude = unarchiveLocation.value(forKey: "next_lat") as! Double
       nextLongitude = unarchiveLocation.value(forKey: "next_long")  as! Double
       currentLatitude =  unarchiveLocation.value(forKey: "current_lat")  as!Double
       currentLongitude =  unarchiveLocation.value(forKey: "current_long") as! Double
            print(unarchiveLocation)
            locationManger.startUpdatingLocation()
        
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        
        let location = locations[0]
        let locationString =  [nextLatitude,nextLongitude]
        var locations : [CLLocation] = []
        currentLocation = location
        let center = CLLocationCoordinate2D(latitude: nextLatitude,longitude: nextLongitude)
        var region = MKCoordinateRegion(center: center, span: MKCoordinateSpan(latitudeDelta: 0.01, longitudeDelta: 0.01))
        region.center = mapView.userLocation.coordinate
        mapView.setRegion(region, animated: true)
        self.mapView.showsUserLocation = true
      

        // TO CONVERT locatioString to CLLocation
        for _ in locationString {
            let location = CLLocation(latitude: currentLatitude, longitude: currentLongitude)
            locations.append(location)
        }
        //check tanyyy 3lihaa
        // to calculate distance b/w my location and pin location
        for location in locations {
            let distanceMeters = currentLocation?.distance(from: location)
            if distanceMeters == 1000 {
                AlertController.showAlert(self, titlee: "Attention", messagee: "Reminder said you have something to do here")
            }
  }
}
    }
    



